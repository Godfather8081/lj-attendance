<?php

require_once dirname(__FILE__).'/dbconnect.php';



if(isset($_POST['subject']))
{


		$subject=$_POST['subject'];
		
        
        $que="INSERT INTO subject VALUES('null','$subject','null')";
    	$eq=mysqli_query($con,$que);



       if($que)
       {
           $response['message']="Add";
		   $response['error']=false;

       }

       else
       {

             $response['message']="Fail To Add";
		     $response['error']=true;
       }
}

else
{

   $response['message']="Data Not Given";
   $response['error']=true;
}


echo json_encode($response);


?>