<?php

require_once dirname(__FILE__).'/dbconnect.php';



if(isset($_POST['name']) and isset($_POST['email']) and isset($_POST['phon']) and isset($_POST['pass']))
{


		$name=$_POST['name'];
		$email=$_POST['email'];
		$enrol="null";
		$phon=$_POST['phon'];
		$pass=$_POST['pass'];
        $date=date("y/m/d");

        
        $que="INSERT INTO request VALUES('null','$name','$email','$enrol','$phon','$pass','f','$date')";
    	$eq=mysqli_query($con,$que);



       if($que)
       {
           $response['message']="Registe";
		   $response['error']=false;

       }

       else
       {

             $response['message']="Fail To Register";
		     $response['error']=true;
       }
}

else
{

   $response['message']="Data Not Given";
   $response['error']=true;
}


echo json_encode($response);


?>