<?php

require_once dirname(__FILE__).'/dbconnect.php';

$response=array();



if(isset($_POST['selected_std']) and isset($_POST['tosem']) and isset($_POST['toclass']))

{

      	$selected_std=$_POST['selected_std'];
      	$toclass=$_POST['toclass'];
      	$tosem=$_POST['tosem'];
      	$cnt=0;
      
    
    
    
           
    
    


    
 	    /*$stdarr=explode(",",$selected_std);
 	    $stdfinalarr=array();
 		

        foreach ($stdarr as  $value) 
		{
			$tmp=$value;
            
            for($i=0;$i<strlen($tmp);$i++)
            {
                if($tmp[$i]=="[" or $tmp[$i]=="]")
                {
                    $tmp[$i]="\0";
                }
            
               
               
            }
             array_push($stdfinalarr,$tmp);
            
            
            
		}


		foreach ($stdfinalarr as  $val) 	
		{
        	$que="UPDATE user SET sem_v='$tosem', classtype_v='$toclass' WHERE enrolment_i='$val'";
         	$eq=mysqli_query($con,$que);
           
		}
*/



 		 $stdarr=explode(",",$selected_std);
 		$stdfinalarr=array();
 		

        foreach ($stdarr as  $value) 
		{
			$tmp=$value;
            
            for($i=0;$i<strlen($tmp);$i++)
            {
                if($tmp[$i]=="[" or $tmp[$i]=="]")
                {
                    $tmp[$i]="\0";
                }
               
               
            }
            $tmp=preg_replace("/[^A-Za-z0-9]/","",$tmp);
            
         //   trim($tmp);
            array_push($stdfinalarr,$tmp);
            
            
            
		}


		foreach ($stdfinalarr as  $val) 	
		{
            $que="UPDATE user SET sem_v='$tosem', classtype_v='$toclass' WHERE enrolment_i='$val'";
         	$eq=mysqli_query($con,$que);
         	$cnt=$cnt+1;
		}


		if($eq)
		{
			$response['error']=false;
		    $response['message']="Allocation Done";			
		}
		
		else
		{
		    $response['error']=true;
		    $response['message']="Fail To Do Allocation";
		}

}

else
{
        $response['error']=true;
		$response['message']="Value Not Given";
    
}

echo json_encode($response);

?>