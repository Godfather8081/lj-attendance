<?php

require_once dirname(__FILE__).'/dbconnect.php';



if(isset($_POST['facultyid']))
{

   
	$facultyid=$_POST['facultyid'];
	

	$que="SELECT * from request";//WHERE email='".$email."' and pass='".$pass."';";
	$eq=mysqli_query($con,$que);


    $tmp=0;
	while($data=mysqli_fetch_array($eq))
	{
	  if($data['id']==$facultyid)
	  {
	  	 $tmp=1;
	     //$response['message']="Successfully Logged in";
	    // $response['error']=false;
	     //$response['uid']=$data['id_i'];
	     //$response['un']=$data['name_v'];
	     //$response['en']=$data['enrolment_i'];
	     $fid=$data['id'];
	     $fn=$data['name_v'];
	     $fem=$data['email_v'];
	     $fen=$data['enrolment_i'];
	     $fcon=$data['phonno_i'];
	     $fpas=$data['pass_v'];
	     $fute=$data['utype_v'];
	     $fcd=$data['creationdate_d'];
	     
	    $que2="INSERT INTO user VALUES('null','$fn','$fem','null','null','$fen','$fcon','$fpas','$fute','$fcd')";
     	$eq2=mysqli_query($con,$que2);
     	
     	if($eq2)
     	{
     	    $que3="DELETE FROM request WHERE id='$fid'";
         	$eq3=mysqli_query($con,$que3);
         	
         	if($eq3)
         	{
                 $response['message']="Done";
	             $response['error']=false;
	     	    
         	}
     	    
     	    
     	}

	     break;
	     
	  }

	  
	}


	if($tmp!=1)
	{
		 $response['message']="User Not Found";
		 $response['error']=true;
	    
	}

}

else
{

   $response['message']="Enrolment Or Password Not Given";
   $response['error']=true;
}


echo json_encode($response);

?>
