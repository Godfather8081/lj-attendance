<?php

require_once dirname(__FILE__).'/dbconnect.php';



if(isset($_POST['enrol']) and isset($_POST['pass']))
{

   
	$enrolment=$_POST['enrol'];
	$pass=$_POST['pass'];

	$que="SELECT * from user";//WHERE email='".$email."' and pass='".$pass."';";
	$eq=mysqli_query($con,$que);


    $tmp=0;
	while($data=mysqli_fetch_array($eq))
	{
	  if($data['enrolment_i']==$enrolment and $data['pass_v']==$pass)
	  {
	  	 $tmp=1;
	     $response['message']="Successfully Logged in";
	     $response['error']=false;
	     $response['uid']=$data['id_i'];
	     $response['un']=$data['name_v'];
	     $response['en']=$data['enrolment_i'];
	     break;
	     
	  }

	  
	}


	if($tmp!=1)
	{
		 $response['message']="User Not Found";
		 $response['error']=true;
	    
	}

}

else
{

   $response['message']="Enrolment Or Password Not Given";
   $response['error']=true;
}


echo json_encode($response);

?>
