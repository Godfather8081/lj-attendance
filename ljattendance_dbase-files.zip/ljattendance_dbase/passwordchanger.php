<?php

require_once dirname(__FILE__).'/dbconnect.php';



if(isset($_POST['uid']) and isset($_POST['newpass']))
{

   	$uid=$_POST['uid'];
	$newpass=$_POST['newpass'];


  	$que='UPDATE user SET pass_v="$newpass" WHERE id_i="$uid"';
	$eq=mysqli_query($con,$que);

    if($eq)
    {
       $response['message']="Password Updated Successfully";
       $response['error']=false;

    }


    else
	{

   		$response['message']="Fail To Updated Password Try Latter";
   		$response['error']=true;
	}


}


else
{

   $response['message']="New Password Not Given";
   $response['error']=true;
}

echo json_encode($response);

?>