<?php

require_once dirname(__FILE__).'/dbconnect.php';

$fresponse=array();

if(isset($_POST['reqid']))
{
	$reqid=$_POST['reqid'];


  if($reqid=="0")
  {
	$que="select * from request";
	$eq=mysqli_query($con,$que);
  }
  
  if($reqid=="1")
  {
	$que="select * from leave_request";
	$eq=mysqli_query($con,$que);
  }
  
  
  
	if($eq)
	{

		$fresponse['error']=false;
		while($data=mysqli_fetch_array($eq))
		{
		    if($reqid=="0")
		    {
		   	 	$fresponse['id']=$data['id'];
		   	 	$fresponse['fname']=$data['name_v'];
		   	 	$fresponse['con']=$data['phonno_i'];
 
 
 

            	array_push($response,$fresponse);
		    }
           
		}
     
	}

	else
	{

		$fresponse['error']=true;
		$fresponse['message']="Not Able To Find  Data";

	}


}

else
{

  	    $fresponse['error']=true;
		$fresponse['message']="Values Not Given";
}

echo json_encode($response);

?>