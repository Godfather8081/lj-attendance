<?php

require_once dirname(__FILE__).'/dbconnect.php';

$response=array();



if(isset($_POST['selected_std']) and isset($_POST['faculty_name']) and isset($_POST['subject']))

{

      	$selected_std=$_POST['selected_std'];
      	$faculty_name=$_POST['faculty_name'];
      	$subject=$_POST['subject'];
      	$lecno=$_POST['lecno'];
      	$classtype=$_POST['classtype'];
      	$sem=$_POST['sem'];
      	$facultyid=$_POST['facultyid'];
      	$date=date("y/m/d");
      	$time=date("h:i:sa");
      	
      	$ss=$selected_std;
      	$fn=$faculty_name;
      	$sb=$subject;
      	$fi=$facultyid;
      	$ct=$classtype;

    
    
    
        $que2="INSERT INTO attendance VALUES('null','$lecno','$ct','$sem','$sb','$fi','$ss','$date','$time')";
        $eq2=mysqli_query($con,$que2);
           
    
    


    
 		 $stdarr=explode(",",$selected_std);
 		$stdfinalarr=array();
 		

        foreach ($stdarr as  $value) 
		{
			$tmp=$value;
            
            for($i=0;$i<strlen($tmp);$i++)
            {
                if($tmp[$i]=="[" or $tmp[$i]=="]")
                {
                    $tmp[$i]="\0";
                }
               
               
            }
            //$tmp=preg_replace("/[^A-Za-z0-9]/","",$tmp);
            
            array_push($stdfinalarr,$tmp);
            
            
		}


		foreach ($stdfinalarr as  $val) 	
		{
        	$que="INSERT INTO today VALUES('null','$val','$date','$faculty_name','$subject')";
         	$eq=mysqli_query($con,$que);
           
		}

		if($eq and$eq2)
		{
			$response['error']=false;
		    $response['message']="Attendance Done";			
		}
		
		else
		{
		    $response['error']=true;
		    $response['message']="Fail To Do Attendance";
		}

}

else
{
        $response['error']=true;
		$response['message']="Value Not Given";
    
}

echo json_encode($response);

?>