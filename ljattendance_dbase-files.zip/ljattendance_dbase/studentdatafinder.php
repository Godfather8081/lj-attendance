<?php

require_once dirname(__FILE__).'/dbconnect.php';

$fresponse=array();

if(isset($_POST['sem']) and isset($_POST['classtype']))
{
	$sem=$_POST['sem'];
    $classtype=$_POST['classtype'];


	$que="select * from user";
	$eq=mysqli_query($con,$que);

	if($eq)
	{

		$fresponse['error']=false;
		while($data=mysqli_fetch_array($eq))
		{
		   if($data['sem_v']==$sem and $data['classtype_v']==$classtype)
           {
		  	 	$fresponse['uenrolno']=$data['enrolment_i'];
 

            	array_push($response,$fresponse);
           }

		}
     
	}

	else
	{

		$fresponse['error']=true;
		$fresponse['message']="Not Able To Find Student's Data";

	}


}

else
{

  	    $fresponse['error']=true;
		$fresponse['message']="Values Not Given";
}

echo json_encode($response);

?>