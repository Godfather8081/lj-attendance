<?php

require_once dirname(__FILE__).'/dbconnect.php';

$fresponse=array();


	$que="select * from subject";
	$eq=mysqli_query($con,$que);

	if($eq)
	{

		$fresponse['error']=false;
		while($data=mysqli_fetch_array($eq))
		{
		   $fresponse['subid']=$data['id_i'];
           $fresponse['subname']=$data['name_v'];
           $fresponse['subcode']=$data['code_i'];

            array_push($response,$fresponse);
		}
     
	}

	else
	{

		$fresponse['error']=false;
		$fresponse['message']="Not Able To Find Data";

	}




echo json_encode($response);


?>