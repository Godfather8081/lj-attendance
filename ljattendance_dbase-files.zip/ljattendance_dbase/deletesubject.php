<?php

require_once dirname(__FILE__).'/dbconnect.php';



if(isset($_POST['selectedsub']))
{

   
	$selectedsub=$_POST['selectedsub'];
	
	 	    $que3="DELETE FROM subject WHERE name_v='$selectedsub'";
         	$eq3=mysqli_query($con,$que3);
         	
         	if($eq3)
         	{
                 $response['message']="Done";
	             $response['error']=false;
	             
         	}
         	
         	
         	else
         	{
         	     $response['message']="Fail";
	             $response['error']=true;
	            
         	}
	     	    
     	    
     	    
}

	
	  
	



else
{

   $response['message']="Value Not  Given";
   $response['error']=true;
}


echo json_encode($response);

?>
