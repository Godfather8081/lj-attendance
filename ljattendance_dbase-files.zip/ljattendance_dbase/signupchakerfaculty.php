<?php

require_once dirname(__FILE__).'/dbconnect.php';



if(isset($_POST['email']) and isset($_POST['phon']))
{

   
	$email=$_POST['email'];
    $phon=$_POST['phon'];


	$que="SELECT * from user WHERE email_v='$email' or phonno_i='$phon'";
	$eq=mysqli_query($con,$que);


   if(mysqli_num_rows($eq)>0)
   {
      
      $response['message']="PhonNo or Email Already Exist";
      $response['error']=true;   	
   }

   else
   {

   	  $response['message']="Ok";
      $response['error']=false;
   }

	
}

else
{

   $response['message']="Email Or Password Not Given";
   $response['error']=true;
}


echo json_encode($response);

?>
