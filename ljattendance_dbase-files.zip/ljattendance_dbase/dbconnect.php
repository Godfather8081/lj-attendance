<?php

$host="localhost";
$user="id7161940_vatsalpatel";
$password="80816555";
$database="id7161940_attendance";
$response=array();

$con=mysqli_connect($host,$user,$password,$database);

if($con)
{
	
  
}

else
{
   
   $response['message']="Not Able To Connect To Database";
	    
}
?>