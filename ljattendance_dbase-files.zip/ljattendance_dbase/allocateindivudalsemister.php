<?php

require_once dirname(__FILE__).'/dbconnect.php';



if(isset($_POST['tosem']) and isset($_POST['toclass']) and isset($_POST['enrolment']) )
{


		$tosem=$_POST['tosem'];
		$toclass=$_POST['toclass'];
		$enrolment=$_POST['enrolment'];
		
        
        $que="UPDATE user SET sem_v='$tosem', classtype_v='$toclass' WHERE enrolment_i='$enrolment'";
        $eq=mysqli_query($con,$que);
         	


       if($que)
       {
           $response['message']="Allocation Done";
		   $response['error']=false;

       }

       else
       {

             $response['message']="User Not Found";
		     $response['error']=true;
       }
}

else
{

   $response['message']="Data Not Given";
   $response['error']=true;
}


echo json_encode($response);


?>