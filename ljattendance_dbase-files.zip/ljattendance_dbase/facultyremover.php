<?php

require_once dirname(__FILE__).'/dbconnect.php';



if(isset($_POST['facultyid']))
{

   
	$facultyid=$_POST['facultyid'];
	

	$que="DELETE FROM user WHERE id_i=$facultyid";//WHERE email='".$email."' and pass='".$pass."';";
	$eq=mysqli_query($con,$que);


    if($eq)
    {
        $response['message']="Done";
	    $response['error']=false;
    }    	    

    else
    {
        $response['message']="Fail";
	    $response['error']=true;
    }
    
}
     	    
     	    
     	
 

	  





else
{

   $response['message']="Value Not Given";
   $response['error']=true;
}


echo json_encode($response);

?>
