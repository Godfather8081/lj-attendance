<?php

require_once dirname(__FILE__).'/dbconnect.php';

$fresponse=array();



  	$que="select * from user";
	$eq=mysqli_query($con,$que);
  

  
  
	if($eq)
	{

		$fresponse['error']=false;
		while($data=mysqli_fetch_array($eq))
		{
		    
		    if($data['utype_v']=='f')
		    {
		   	 	$fresponse['id']=$data['id_i'];
		   	 	$fresponse['fname']=$data['name_v'];
		   	 	$fresponse['con']=$data['phonno_i'];
 
		    
 

            	array_push($response,$fresponse);
		    }
		}
     
	}

	else
	{

		$fresponse['error']=true;
		$fresponse['message']="Not Able To Find  Data";

	}



echo json_encode($response);

?>