<?php

require_once dirname(__FILE__).'/dbconnect.php';


if(isset($_POST['enrolment']) and isset($_POST['phon']) and isset($_POST['newpass']))
{
  
    $enrol=$_POST['enrolment'];
	$phon="+91".$_POST['phon'];
    $newpass=$_POST['newpass'];

    
    $que="SELECT * from user";//WHERE email='".$email."' and pass='".$pass."';";
	$eq=mysqli_query($con,$que);

    

    $tmp=0;
	while($data=mysqli_fetch_array($eq))
	{
	  if($data['enrolment_i']==$enrol and $data['phonno_i']==$phon)
	  {
	  	 $tmp=1;
	     $response['message']="User Found";
	     $response['error']=false;
	     $response['uid']=$data['id_i'];
	     break;
	     
	  }

	  
	}


	if($tmp!=1)
	{
		 $response['message']="User Or Phone Number Not Found";
		 $response['error']=true;
	    
	}



}


else
{

   $response['message']="Enrolment Or Password Not Given";
   $response['error']=true;
}


echo json_encode($response);


?>